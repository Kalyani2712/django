from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.shortcuts import get_object_or_404
from .forms import RegistrationForm, LoginForm, ProductForm
from .models import Product, Category, Order, OrderItem, Cart
from django.db.models import Sum
import datetime
from django.contrib.auth import get_user_model
User = get_user_model()

# Show index page
def index(request):
    return render(request, 'index.html')

# Register a new user using the form
def register_customer(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])  # Hash the password
            user.save()
            messages.success(request, "Registration successful! Please log in.")
            return redirect('login')
        else:
            messages.error(request, "There were errors in your registration form.")
    else:
        form = RegistrationForm()

    return render(request, 'register.html', {'form': form})

# Log in an existing user using the form
def login_customer(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f"Welcome {user.username}!")
                return redirect('dashboard')
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid form submission.")
    else:
        form = LoginForm()

    return render(request, 'login.html', {'form': form})

# Show dashboard (only for authenticated users)
# Corrected dashboard view
def dashboard_customer(request):
    if not request.user.is_authenticated:
        messages.warning(request, "You must log in to access the dashboard.")
        return redirect('login')

    # Stats for the dashboard cards
    total_products = Product.objects.count()
    today = datetime.date.today()
    
    # Change 'order_date' to 'created_at' as per the available field in your Order model
    today_orders = Order.objects.filter(created_at__date=today).count()
    
    # Calculate total revenue for today (using 'created_at' instead of 'order_date')
    today_revenue = (
        Order.objects
             .filter(created_at__date=today)
             .aggregate(sum=Sum('total'))['sum']
        or 0
    )
    
    total_customers = User.objects.count()

    # Lists for tables
    recent_orders = Order.objects.order_by('-created_at')[:5]
    products = Product.objects.all()

    return render(request, 'dashboard.html', {
        'total_products': total_products,
        'today_orders': today_orders,
        'today_revenue': today_revenue,
        'total_customers': total_customers,
        'recent_orders': recent_orders,
        'products': products,
        'cart_items_count': Cart.objects.filter(user=request.user).count(),
    })


# Log out the user
def logout_user(request):
    logout(request)
    messages.success(request, "Logged out successfully.")
    return redirect('login')

# Add new product (admin access assumed, using form)
def add_item(request):
    if not request.user.is_authenticated:
        return redirect('login')

    if request.method == "POST":
        form = ProductForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Product added successfully.")
            return redirect("dashboard")
        else:
            messages.error(request, "There was an error adding the product.")
    else:
        form = ProductForm()

    return render(request, "add.html", {'form': form})

# Optional edit view

def edit_product(request, product_id):
    if not request.user.is_authenticated:
        return redirect('login')

    product = get_object_or_404(Product, id=product_id)

    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        if form.is_valid():
            form.save()
            messages.success(request, "Product updated successfully.")
            return redirect('dashboard')
        else:
            messages.error(request, "There was an error updating the product.")
    else:
        form = ProductForm(instance=product)

    return render(request, 'edit.html', {'form': form, 'product': product})
def delete_product(request, product_id):
    if not request.user.is_authenticated:
        return redirect('login')

    product = get_object_or_404(Product, id=product_id)

    if request.method == 'POST':
        product.delete()
        messages.success(request, "Product deleted successfully.")
        return redirect('dashboard')

    return render(request, 'delete_product.html', {'product': product})


def profile(request):
    return render(request, "profile.html")

def cart(request):
    if not request.user.is_authenticated:
        return redirect('login')

    cart_items = Cart.objects.filter(user=request.user)
    total_price = sum(item.product.price * item.quantity for item in cart_items)

    return render(request, 'cart.html', {
        'cart_items': cart_items,
        'total_price': total_price,
    })

def notifications(request):
    return render(request, 'notifications.html')

def order_detail(request, order_id):
    if not request.user.is_authenticated:
        return redirect('login')

    order = Order.objects.get(id=order_id, user=request.user)
    order_items = OrderItem.objects.filter(order=order)

    return render(request, 'order_detail.html', {
        'order': order,
        'order_items': order_items,
    })

def edit_order(request, order_id):  
    if not request.user.is_authenticated:
        return redirect('login')

    order = Order.objects.get(id=order_id, user=request.user)
    order_items = OrderItem.objects.filter(order=order)

    if request.method == 'POST':
        # Handle form submission to edit order details
        # (This part is left for you to implement based on your requirements)
        pass

    return render(request, 'edit_order.html', {
        'order': order,
        'order_items': order_items,
    })  
def delete_product(request, product_id):
    if not request.user.is_authenticated:
        return redirect('login')

    product = Product.objects.get(id=product_id)
    if request.method == 'POST':
        product.delete()
        messages.success(request, "Product deleted successfully.")
        return redirect('dashboard')

    return render(request, 'delete_product.html', {'product': product}) 

    