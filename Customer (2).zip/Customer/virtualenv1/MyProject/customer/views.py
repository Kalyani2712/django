from django.shortcuts import render, redirect
from django.contrib.auth.hashers import check_password
from django.contrib import messages
from .forms import customerForm  # Ensure the form name matches
from .models import customer  # Ensure you're using the correct model name

# Create your views here.
def index(request):
    return render(request, 'index.html')

def register_customer(request):
    if request.method == 'POST':
        # Retrieving form data
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        address = request.POST.get('address')
        password = request.POST.get('password')

        print(first_name, last_name, email, phone, address, password, "user registration started")

        # Using the CustomerForm to validate the form data
        cform = customerForm(request.POST)
        
        if cform.is_valid():
            customer = cform.save(commit=False)
            customer.set_password(password)  # Hash the password before saving
            customer.save()  # Save the customer instance with hashed password
            messages.success(request, "Registration successful! Please log in.")
            return redirect('login')
        else:
            messages.error(request, "There was an error in your form. Please try again.")
            return redirect('register')
    
    return render(request, 'register.html', {'form': customerForm()})

def login_customer(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        try:
            user = customer.objects.get(email=email)  # Fetch user by email
            if user.check_password(password):  # Verify hashed password
                request.session['customer_id'] = user.id
                request.session['customer_name'] = user.first_name
                return redirect('dashboard')  # Redirect to dashboard if login is successful
            else:
                messages.error(request, 'Invalid password')
        except customer.DoesNotExist:
            messages.error(request, 'User not found')

    return render(request, 'login.html')  # Render login page if login fails

def dashboard_customer(request):
    return render(request, 'dashboard.html')
