from django.db import models
from django.contrib.auth.hashers import make_password  # Import to hash passwords

# Create your models here.
class customer(models.Model):  # Renamed to Customer (capitalized)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(max_length=100, unique=True)
    phone = models.CharField(max_length=15, unique=True)
    address = models.CharField(max_length=255)
    password = models.CharField(max_length=255)

    def set_password(self, raw_password):
        self.password = make_password(raw_password)  # Hash the password

    def check_password(self, raw_password):
        from django.contrib.auth.hashers import check_password
        return check_password(raw_password, self.password)  # Verify hashed password
    
    

    def __str__(self):
        return f'{self.first_name} {self.last_name}'
